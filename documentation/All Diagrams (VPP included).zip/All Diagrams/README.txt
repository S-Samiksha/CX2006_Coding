Diagrams_Final.vpp includes:
Class Diagram
Sequence diagram(UC001-UC008)
Initial Dialog Map

UseCaseDiagramFinal.vpp includes:
Use case diagram

All screenshots of the diagrams are also included in this folder